package pComponent;

import java.awt.Component;
import pModel.ModelBunga;

public interface EventItem {
    public void itemClick(Component com, ModelBunga bunga);
}
