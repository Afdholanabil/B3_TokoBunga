package pConnection;


public class ConnectionClass {
    
    public static String linkUrl = "https://dimazz.000webhostapp.com/ApiTokoBunga/";
//    public static String linkUrl = "http://192.168.1.4:8080/ApiTokoBunga/";
}
